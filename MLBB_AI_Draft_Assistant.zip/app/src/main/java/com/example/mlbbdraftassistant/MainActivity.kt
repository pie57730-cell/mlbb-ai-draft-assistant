package com.example.mlbbdraftassistant

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : androidx.activity.ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DraftAssistantScreen() }
    }
}

@Composable
fun DraftAssistantScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var imageBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var extractedText by remember { mutableStateOf("Pilih screenshot draft dari galeri untuk mula.") }
    var detectedHeroes by remember { mutableStateOf(listOf<String>()) }
    var busy by remember { mutableStateOf(false) }

    val heroNames = remember {
        listOf(
            "Tigreal", "Miya", "Fanny", "Layla", "Nana", "Chou", "Franco", "Angela",
            "Balmond", "Alucard", "Saber", "Karina", "Eudora", "Zilong", "Gusion",
            "Lesley", "Lancelot", "Kagura", "Lunox", "Atlas", "Ling", "Yu Zhong",
            "Paquito", "Beatrix", "Melissa", "Fredrinn", "Arlott", "Joy", "Novaria",
            "Nolan", "Cici", "Kalea", "Suyou", "Zhuxin", "Ixia", "Harith"
        )
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true
                try {
                    val bitmap = if (Build.VERSION.SDK_INT >= 28) {
                        val source = ImageDecoder.createSource(context.contentResolver, uri)
                        ImageDecoder.decodeBitmap(source)
                    } else {
                        @Suppress("DEPRECATION")
                        MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                    }
                    imageBitmap = bitmap
                    val input = InputImage.fromBitmap(bitmap, 0)
                    val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    val result = recognizer.process(input).await()
                    extractedText = result.text.ifBlank {
                        "OCR tidak menemui teks yang jelas. Portrait hero mungkin memerlukan pengecaman imej khusus."
                    }
                    val normalized = result.text.lowercase()
                    detectedHeroes = heroNames.filter { normalized.contains(it.lowercase()) }.distinct()
                } catch (e: Exception) {
                    extractedText = "Gagal memproses imej: ${e.localizedMessage ?: "Ralat tidak diketahui"}"
                    detectedHeroes = emptyList()
                } finally {
                    busy = false
                }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("MLBB AI Draft Assistant", style = MaterialTheme.typography.headlineSmall)
                Text("Screenshot companion • MVP", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Analisis screenshot yang dipilih secara manual. Versi ini menggunakan OCR untuk membaca nama hero yang tertulis; ia belum mengecam portrait hero secara visual dan tidak mengawal permainan.",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = { picker.launch("image/*") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "Sedang menganalisis…" else "Pilih screenshot dari galeri")
                }
                imageBitmap?.let { bitmap ->
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Screenshot dipilih",
                        modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp)
                    )
                }
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Hero yang dikesan melalui OCR", style = MaterialTheme.typography.titleMedium)
                        if (detectedHeroes.isEmpty()) {
                            Text("Belum ada nama hero dikenal pasti.")
                        } else {
                            detectedHeroes.forEach { Text("• $it") }
                        }
                    }
                }
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Teks OCR", style = MaterialTheme.typography.titleMedium)
                        Text(extractedText)
                    }
                }
                Text("Nota: OCR mungkin tersilap atau terlepas nama. Cadangan counter-pick dan database penuh belum disertakan dalam MVP ini.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
