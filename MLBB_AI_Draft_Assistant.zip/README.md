# MLBB AI Draft Assistant (MVP)

Android Studio project for a manual screenshot companion.

## Current features
- Pick an image/screenshot from the gallery using Android's photo picker.
- Runs ML Kit Latin text recognition locally on the selected image.
- Detects a limited list of hero names if they appear as readable text.
- Shows OCR text and the selected screenshot.

## Not included yet
- Visual hero portrait recognition or complete official hero database.
- Counter-pick recommendations.
- Floating overlay service.
- Real-time capture or game control.
- Gemini API integration.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish (internet connection required to download dependencies).
3. Build > Build APK(s).

This project has not been compiled in this environment; build and test it in Android Studio before installing.
